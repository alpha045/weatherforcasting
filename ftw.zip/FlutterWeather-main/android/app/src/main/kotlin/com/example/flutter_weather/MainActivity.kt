package com.example.flutter_weather

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
